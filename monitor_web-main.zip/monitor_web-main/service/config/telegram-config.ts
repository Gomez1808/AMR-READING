class TelegramConfig {
    tokenID = "6551011335:AAHPJ2xRTD1YDaW6a0Y4U9OcLNzzy2FvsPM"
    chatID = "1133474771"
}

export default TelegramConfig