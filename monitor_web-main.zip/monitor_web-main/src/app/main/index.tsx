import Router from 'next/router'
import React, { useEffect } from 'react'

import DashboardPageController from "../../../service/controller/page/dashboard_page_controller"
import AdminLayout from "./components/layout"
import { Box } from '@chakra-ui/react'
import { LoadData, LoadDialog } from 'web/components/load'
import DashboardFragment from './fragment/dashboard'
import CategoryFrgament from './fragment/category'

type DashboardScreenModel = {
    controller: DashboardPageController
}

const DashboardView = () => {
    var controller = new DashboardPageController()

    const checkSession = async () => {
        var result = await controller.checkSession()

        if (result === false) {
            await Router.push('/sign-in')
        }
    }

    useEffect(() => {
        checkSession()
    }, [])

    return controller.pageLoad == false
        ? (
            <div>
                <AdminLayout controller={controller}>
                    <DashboardScreen controller={controller} />
                </AdminLayout>
                <LoadDialog isOpen={controller.navigateLoad} />
            </div>
        )
        : (
            <Box
                minHeight='100vh'
                height='100%'
                overflow='auto'
                position='relative'
                maxHeight='100%'
            >
                <LoadData />
            </Box>
        )
}

const DashboardScreen = ({ controller }: DashboardScreenModel) => {
    if (controller.pageIndex == 0) {
        return (
            <DashboardFragment />
        )
    } else if (controller.pageIndex == 1) {
        return (
            <CategoryFrgament />
        )
    } else {
        return (
            <div>

            </div>
        )
    }
}

export default DashboardView