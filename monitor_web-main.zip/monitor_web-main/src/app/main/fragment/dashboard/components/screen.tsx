import DashboardFrgamentController from "../../../../../../service/controller/fragment/dashboard_fragment_controller"

import {
    SimpleGrid,
} from "@chakra-ui/react"

import CardData from "./card"
import { MdGrain, } from "react-icons/md"
import ChartData from "./chart_data"
import DataModel from "../../../../../../service/model/data"

type ScreenModel = {
    controller: DashboardFrgamentController
    data: DataModel[]
}

const ScreenPage = ({ controller, data }: ScreenModel) => {
    return (
        <>
            <SimpleGrid gap='20px' mb='20px'>
                <ChartData controller={controller} />
            </SimpleGrid>
            <SimpleGrid
                columns={{ base: 1, md: 2, lg: 3, '2xl': 6 }}
                gap='20px'
                mb='20px'
            >
                {
                    controller.dataCategory.map((value, index, array) => {
                        return (
                            <CardData
                                key={value.idCategory}
                                controller={controller}
                                label={`${value.nameCategory} ${value.unitCategory}`}
                                value={value.idCategory}
                                icon={MdGrain}
                                listData={data} />
                        )
                    })
                }
            </SimpleGrid>
        </>
    )
}

export default ScreenPage