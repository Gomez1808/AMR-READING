import { Button, useColorModeValue } from "@chakra-ui/react"
import DashboardFrgamentController from "../../../../../../service/controller/fragment/dashboard_fragment_controller"

type ComponentModel = {
    controller: DashboardFrgamentController
    isEnable: boolean
    onClick: () => void
}

const SubmitButton = ({ controller, isEnable, onClick }: ComponentModel) => {
    let bgButton = 'linear-gradient(135deg, #868CFF 0%, #4318FF 100%)'
    const shadow = useColorModeValue(
        '14px 17px 40px 4px rgba(112, 144, 176, 0.18)',
        '14px 17px 40px 4px rgba(112, 144, 176, 0.06)'
    );

    return (
        <Button
            variant='darkBrand'
            _hover={{ bg: 'brand.500' }}
            _focus={{ bg: 'brand.500' }}
            color='white'
            fontSize='sm'
            fontWeight='500'
            borderRadius='70px'
            px='24px'
            py='5px'
            bg={bgButton}
            isDisabled={isEnable ? false : true}
            onClick={onClick}
        >
            SUBMIT
        </Button>
    )
}

export default SubmitButton