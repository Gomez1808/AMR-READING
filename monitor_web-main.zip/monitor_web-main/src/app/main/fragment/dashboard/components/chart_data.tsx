import {
    Box,
    Button,
    Flex,
    Icon,
    Text,
    useColorModeValue
} from '@chakra-ui/react';

import Card from 'web/components/card/Card';
import { MdBarChart } from 'react-icons/md';

import DashboardFrgamentController from '../../../../../../service/controller/fragment/dashboard_fragment_controller';
// import LineChart from 'web/components/charts/LineAreaChart';
import { lineChartDataTotalSpent, lineChartOptionsTotalSpent } from '../service/line_chart';
import CategoryConfig from './category';
import LineChart from 'web/components/charts/LineAreaChart';

type ChartModel = {
    controller: DashboardFrgamentController
}

const ChartData = ({ controller }: ChartModel) => {
    const textColor = useColorModeValue('secondaryGray.900', 'white');
    const iconColor = useColorModeValue('brand.500', 'white');
    const bgButton = useColorModeValue('secondaryGray.300', 'whiteAlpha.100');
    const bgHover = useColorModeValue({ bg: 'secondaryGray.400' }, { bg: 'whiteAlpha.50' });
    const bgFocus = useColorModeValue({ bg: 'secondaryGray.300' }, { bg: 'whiteAlpha.100' });

    return (
        <Card justifyContent='center' alignItems='center' flexDirection='column' w='100%' mb='0px'>
            <Flex justify='space-between' ps='0px' pe='20px' pt='5px' w='100%'>
                <Flex align='center' w='100%'>
                    <Text
                        me='auto'
                        color={textColor}
                        fontSize='xl'
                        fontWeight='700'
                        lineHeight='100%'
                    >
                        Flow Data
                    </Text>
                    <Button
                        ms='auto'
                        alignItems='center'
                        justifyContent='center'
                        bg={bgButton}
                        _hover={bgHover}
                        _focus={bgFocus}
                        _active={bgFocus}
                        w='37px'
                        h='37px'
                        lineHeight='100%'
                        borderRadius='10px'
                    >
                        <Icon as={MdBarChart} color={iconColor} w='24px' h='24px' />
                    </Button>
                </Flex>
            </Flex>
            <Flex w='100%' flexDirection={{ base: 'column', lg: 'row' }}>
                <CategoryConfig controller={controller} />
                <Box minH='260px' minW='75%' mt='auto'>
                    {
                        controller.dataSelectedCategory.length > 0 && controller.chartLoad == false
                            ? (
                                <LineChart
                                    chartData={lineChartDataTotalSpent(
                                        controller,
                                        controller.dataCategory.filter((e) => e.idCategory == controller.dataSelectedCategory[0])[0],
                                        controller.dataCategory.filter((e) => e.idCategory == controller.dataSelectedCategory[1])[0],
                                        controller.dataCategory.filter((e) => e.idCategory == controller.dataSelectedCategory[2])[0],
                                    )}
                                    chartOptions={lineChartOptionsTotalSpent(controller)} />
                            )
                            : (<></>)
                    }
                </Box>
            </Flex>
        </Card>
    );
}

export default ChartData