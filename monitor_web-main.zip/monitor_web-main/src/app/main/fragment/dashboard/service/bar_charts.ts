import { ApexOptions } from "apexcharts";
import DashboardFrgamentController from "../../../../../../service/controller/fragment/dashboard_fragment_controller";
import { monthOnlyFormater } from "../../../../../../service/service/formatter/date";
import CategoryModel from "../../../../../../service/model/category";

type ApexGeneric = ApexOptions & any;

export const barChartDataConsumption = 
    (controller: DashboardFrgamentController, category_1: CategoryModel, category_2: CategoryModel) => {
    var data_1 = controller.dataDatas.filter((e) => {e.idCategory == category_1.idCategory}).map((e) => e.valueData)
    var data_2 = controller.dataDatas.filter((e) => {e.idCategory == category_2.idCategory}).map((e) => e.valueData)

    return [
        {
            name: `${category_1.nameCategory} ${category_1.unitCategory}`,
            data: data_1,
        },
        {
            name: "Expense",
            data: data_2,
        },
    ]
};

export const barChartOptionsConsumption = (controller: DashboardFrgamentController) => {
    var data = controller.dataDatas.map(data => monthOnlyFormater(data.createData))
    var transaction = Array.from(new Set(data))

    return {
        chart: {
            stacked: true,
            toolbar: {
                show: false,
            },
        },
        tooltip: {
            style: {
                fontSize: "12px",
                fontFamily: undefined,
            },
            onDatasetHover: {
                style: {
                    fontSize: "12px",
                    fontFamily: undefined,
                },
            },
            theme: "dark",
        },
        xaxis: {
            categories: transaction,
            show: false,
            labels: {
                show: true,
                style: {
                    colors: "#A3AED0",
                    fontSize: "14px",
                    fontWeight: "500",
                },
            },
            axisBorder: {
                show: false,
            },
            axisTicks: {
                show: false,
            },
        },
        yaxis: {
            show: false,
            color: "black",
            labels: {
                show: false,
                style: {
                    colors: "#A3AED0",
                    fontSize: "14px",
                    fontWeight: "500",
                },
            },
        },
        grid: {
            borderColor: "rgba(163, 174, 208, 0.3)",
            show: true,
            yaxis: {
                lines: {
                    show: false,
                    opacity: 0.5,
                },
            },
            row: {
                opacity: 0.5,
            },
            xaxis: {
                lines: {
                    show: false,
                },
            },
        },
        fill: {
            type: "solid",
            colors: ["#ff3946", "#4318FF"],
        },
        legend: {
            show: false,
        },
        colors: ["#ff3946", "#4318FF"],
        dataLabels: {
            enabled: false,
        },
        plotOptions: {
            bar: {
                borderRadius: 10,
                columnWidth: "20px",
            },
        },
    } as ApexGeneric
};