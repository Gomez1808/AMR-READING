import { ApexOptions } from "apexcharts";
import DashboardFrgamentController from "../../../../../../service/controller/fragment/dashboard_fragment_controller";
import { dateTimeFormater } from "../../../../../../service/service/formatter/date";
import CategoryModel from "../../../../../../service/model/category";

export const lineChartDataTotalSpent =
    (controller: DashboardFrgamentController, category_1: CategoryModel, category_2: CategoryModel, category_3: CategoryModel) => {
        var data = controller.dataDatas
        data.sort((a, b) => Date.parse(a.createData.toString()) - Date.parse(b.createData.toString()));

        var data_1 = data.filter((e) => e.idCategory == category_1.idCategory).map((e) => e.valueData)
        var data_2 = data.filter((e) => e.idCategory == category_2.idCategory).map((e) => e.valueData)
        var data_3 = data.filter((e) => e.idCategory == category_3.idCategory).map((e) => e.valueData)

        return [
            {
                name: `${category_1.nameCategory} ${category_1.unitCategory}`,
                data: data_1,
            },
            {
                name: `${category_2.nameCategory} ${category_2.unitCategory}`,
                data: data_2,
            },
            {
                name: `${category_3.nameCategory} ${category_3.unitCategory}`,
                data: data_3,
            },
        ]
    };

export const lineChartOptionsTotalSpent = (controller: DashboardFrgamentController) => {
    var data = controller.dataDatas.map(data => dateTimeFormater(data.createData))
    var value = Array.from(new Set(data))

    return {
        chart: {
            toolbar: {
                show: false,
            },
            dropShadow: {
                enabled: true,
                top: 13,
                left: 0,
                blur: 10,
                opacity: 0.1,
                color: "#4318FF",
            },
        },
        colors: ["#4318FF", "#ff3946", "#74A12E"],
        markers: {
            size: 0,
            colors: "white",
            strokeColors: "#7551FF",
            strokeWidth: 3,
            strokeOpacity: 0.9,
            strokeDashArray: 0,
            fillOpacity: 1,
            discrete: [],
            shape: "circle",
            radius: 2,
            offsetX: 0,
            offsetY: 0,
            showNullDataPoints: true,
        },
        tooltip: {
            theme: "dark",
        },
        dataLabels: {
            enabled: false,
        },
        stroke: {
            curve: "smooth",
            type: "line",
        },
        xaxis: {
            // type: "numeric",
            categories: value,
            labels: {
                style: {
                    colors: "#A3AED0",
                    fontSize: "12px",
                    fontWeight: "500",
                },
            },
            axisBorder: {
                show: false,
            },
            axisTicks: {
                show: false,
            },
        },
        yaxis: {
            show: false,
        },
        legend: {
            show: false,
        },
        grid: {
            show: false,
            column: {
                // color: ["#7551FF", "#39B8FF"],
                opacity: 0.5,
            },
        },
        // color: ["#7551FF", "#39B8FF"],
    } as ApexOptions
};