import { Box } from '@chakra-ui/react';

import DashboardFrgamentController from '../../../../../service/controller/fragment/dashboard_fragment_controller';
import { useEffect, useState } from 'react';
import { LoadData } from 'web/components/load';
import ScreenPage from './components/screen';
import supabaseConfig from '../../../../../service/config/supabase-config';
import DataModel from '../../../../../service/model/data';

const DashboardFragment = () => {
    var controller = new DashboardFrgamentController()
    const [stream, setStream] = useState([] as DataModel[])

    const setData = async (newData: any) => {
        let listData = stream
        let data = DataModel.fromJson(newData)

        listData.push(data)
        setStream(listData)
    }

    useEffect(() => {
        controller.getData()

        supabaseConfig.supabase
            .channel("room1")
            .on('postgres_changes',
                { event: 'INSERT', schema: 'public', table: 'tblData' },
                async payload => await setData(payload.new))
            .subscribe()
    }, [])


    return controller.pageLoad == false
        ? (
            <Box mt={{ base: '180px', md: '80px', xl: '80px' }}>
                <ScreenPage
                    controller={controller}
                    data={stream.length > 0 ? stream : controller.dataDatas} />
            </Box>
        )
        : (<LoadData />)
}

export default DashboardFragment