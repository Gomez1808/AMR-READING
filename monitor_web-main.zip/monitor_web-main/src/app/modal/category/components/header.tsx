import {
    ModalHeader,
    Text
} from "@chakra-ui/react"
import CategoryModalController from "../../../../../service/controller/modal/category_modal_controller"

type HeaderModel = {
    controller: CategoryModalController
}

const HeaderModal = ({ controller }: HeaderModel) => {

    return (
        <ModalHeader>
            <Text textAlign={['left', 'center']} >
                {controller.setModal.idCategory == null ? 'Tambah Kategori' : 'Edit Kategori'}
            </Text>
        </ModalHeader>
    )
}

export default HeaderModal