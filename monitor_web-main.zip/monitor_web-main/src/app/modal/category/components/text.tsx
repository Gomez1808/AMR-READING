import {
    FormLabel,
    Input,
    Text,
    Textarea,
    useColorModeValue
} from "@chakra-ui/react";

import CategoryModalController from "../../../../../service/controller/modal/category_modal_controller";

type FieldModel = {
    controller: CategoryModalController,
    service: string,
    label: string,
    area?: boolean
    value: string,
}

const TextField = ({ controller, service, label, area, value }: FieldModel) => {
    const textColor = useColorModeValue('navy.700', 'white');
    const brandStars = useColorModeValue('brand.500', 'brand.400');

    return (
        <div>
            <FormLabel display='flex' ms='4px' fontSize='sm' fontWeight='500' color={textColor} mb='8px'>
                {label}<Text color={brandStars}>*</Text>
            </FormLabel>
            <InputArea
                controller={controller}
                service={service}
                label={label}
                area={area}
                value={value}
            />
        </div>
    )
}

const InputArea = ({ controller, service, label, area, value }: FieldModel) => {
    const textColor = useColorModeValue('navy.700', 'white');
    return area === true
        ? (
            <Textarea
                key={service}
                isRequired={true}
                fontSize='sm'
                ms={{ base: '0px', md: '0px' }}
                placeholder={label}
                mb='24px'
                fontWeight='500'
                size='lg'
                borderRadius={'15px'}
                color={textColor}
                value={value}
                onChange={(e) => controller.changeForm(e.target.value, service)}
            />
        )
        : (
            <Input
                key={service}
                isRequired={true}
                fontSize='sm'
                ms={{ base: '0px', md: '0px' }}
                type='text'
                placeholder={label}
                mb='24px'
                fontWeight='500'
                size='lg'
                borderRadius={'15px'}
                color={textColor}
                value={value}
                onChange={(e) => controller.changeForm(e.target.value, service)}
            />
        )
}

export default TextField