import {
    Box,
    Button,
    FormControl,
    ModalBody,
    ModalFooter,
    useColorMode,
    useColorModeValue
} from "@chakra-ui/react"

import CategoryModalController from "../../../../../service/controller/modal/category_modal_controller"
import CategoryFrgamentController from "../../../../../service/controller/fragment/category_fragment_controller"

import TextField from "./text"
import { LoadData } from "web/components/load"

type ScreenModel = {
    controller: CategoryModalController
    fragmentController?: CategoryFrgamentController
}

const ScreenModal = ({ controller, fragmentController }: ScreenModel) => {
    const { colorMode, toggleColorMode } = useColorMode()
    let bgButton = 'linear-gradient(135deg, #868CFF 0%, #4318FF 100%)'
    const shadow = useColorModeValue(
        '14px 17px 40px 4px rgba(112, 144, 176, 0.18)',
        '14px 17px 40px 4px rgba(112, 144, 176, 0.06)'
    );

    const actionData = async () => {
        var mode = colorMode === 'light' ? 'light' : 'dark'
        var result = await controller.validateData(mode, fragmentController)
    }

    return (
        <>
            <ModalBody>
                <ScreenView controller={controller} />
            </ModalBody>

            <ModalFooter>
                {controller.preload == false
                    ? (
                        <Button
                            boxShadow={shadow}
                            bg={bgButton}
                            variant='darkBrand'
                            color='white'
                            fontSize='sm'
                            fontWeight='500'
                            borderRadius='70px'
                            px='24px'
                            py='5px'
                            onClick={() => actionData()}
                        >
                            {controller.setModal.idCategory == null
                                ? 'Tambah Kategori'
                                : 'Edit Kategori'}
                        </Button>
                    )
                    : (<></>)
                }
            </ModalFooter>
        </>
    )
}

const ScreenView = ({ controller }: ScreenModel) => {
    return controller.preload == false
        ? (
            <FormControl>
                <TextField controller={controller} service="txt_id" label="ID Kategori" value={controller.form['txt_id']} />
                <TextField controller={controller} service="txt_name" label="Nama Kategori" value={controller.form['txt_name']} />
                <TextField controller={controller} service="txt_unit" label="Satuan" value={controller.form['txt_unit']} />
                {/* <TextField controller={controller} service="txt_desc" label="Deskripsi Kategori" area={true} value={controller.form['txt_desc']} /> */}
            </FormControl>
        )
        : (
            <Box
                minHeight='30vh'
                height='40%'
                overflow='auto'
                position='relative'
                maxHeight='40%'
            >
                <LoadData />
            </Box>
        )
}

export default ScreenModal