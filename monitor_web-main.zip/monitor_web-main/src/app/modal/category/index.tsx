import {
    Modal,
    ModalOverlay,
    ModalContent,
    ModalCloseButton,
} from "@chakra-ui/react"

import CategoryModalController from "../../../../service/controller/modal/category_modal_controller"
import CategoryFrgamentController from "../../../../service/controller/fragment/category_fragment_controller"

import ScreenModal from "./components/screen"
import HeaderModal from "./components/header"
import { useEffect } from "react"

type ModalModel = {
    controller: CategoryModalController
    fragmentController?: CategoryFrgamentController
}

const CategoryModal = ({ controller, fragmentController }: ModalModel) => {

    useEffect(() => {
        controller.getData()
    }, [])


    return (
        <Modal
            size={'xl'}
            isOpen={controller.setModal.isOpen}
            onClose={controller.configModal}
            scrollBehavior={'inside'}
        >
            <ModalOverlay />
            <ModalContent borderRadius={'30px'}>
                <HeaderModal controller={controller} />
                <ModalCloseButton />
                <ScreenModal
                    controller={controller}
                    fragmentController={fragmentController} />
            </ModalContent>
        </Modal>
    )
}

export default CategoryModal