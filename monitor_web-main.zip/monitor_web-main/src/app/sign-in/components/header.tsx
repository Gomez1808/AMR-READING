import {
    Box,
    Heading,
    Text
} from "@chakra-ui/react";
import { useColorModeValue } from "@chakra-ui/system";

export const HeaderAuth = () => {
    const textColor = useColorModeValue('navy.700', 'white');
    const textColorSecondary = 'gray.400';

    return (
        <Box me='auto'>
            <Heading color={textColor} fontSize='36px' mb='10px'>
                Sign In
            </Heading>
            <Text mb='36px' ms='4px' color={textColorSecondary} fontWeight='400' fontSize='md'>
                Enter your email and password to sign in!
            </Text>
        </Box>
    )
}