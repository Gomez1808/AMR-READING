import {
    Text,
    Checkbox,
    Flex,
    FormControl,
    FormLabel,
    Link,
    useColorModeValue
} from "@chakra-ui/react"

import AuthPageController from "../../../../service/controller/page/auth_page_controller";

type ServiceAuthMode = {
    controller : AuthPageController
}

export const ServiceAuth = ({ controller } : ServiceAuthMode) => {
    const textColor = useColorModeValue('navy.700', 'white');
    const textColorBrand = useColorModeValue('brand.500', 'white');

    return (
        <Flex justifyContent='space-between' align='center' mb='24px'>
            <FormControl display='flex' alignItems='center'>
                <Checkbox
                    id='snk'
                    colorScheme='brandScheme'
                    me='10px'
                    isChecked={controller.snk}
                    onChange={() => controller.checkSnk()}
                />
                <FormLabel
                    htmlFor='snk'
                    mb='0'
                    fontWeight='normal'
                    color={textColor}
                    fontSize='sm'>
                    Agree with our
                    <Link mx='3px' color={textColorBrand} href='https://excitech-profile.vercel.app/' target='_blank' fontWeight='normal'>
                        Terms and Condition
                    </Link>
                </FormLabel>
            </FormControl>
            {/* <Link href='/auth/forgot-password'>
                <Text color={textColorBrand} fontSize='sm' w='124px' fontWeight='500'>
                    Forgot password?
                </Text>
            </Link> */}
        </Flex>
    )
}