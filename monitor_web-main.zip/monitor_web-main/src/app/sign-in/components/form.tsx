import {
    FormControl,
    FormLabel,
    Input,
    InputGroup,
    InputRightElement,
    Icon,
    Text,
    useColorModeValue
} from "@chakra-ui/react"
import React from "react";

import { MdOutlineRemoveRedEye } from "react-icons/md"
import { RiEyeCloseLine } from "react-icons/ri"
import AuthPageController from "../../../../service/controller/page/auth_page_controller";
import { ServiceAuth } from "./service";
import { SignInButton } from "./button";

type FormModel = {
    controller: AuthPageController
}

export const FormSignIn = ({ controller }: FormModel) => {
    const textColor = useColorModeValue('navy.700', 'white');
    const textColorSecondary = 'gray.400';
    const brandStars = useColorModeValue('brand.500', 'brand.400');

    return (
        <FormControl>
            <FormLabel display='flex' ms='4px' fontSize='sm' fontWeight='500' color={textColor} mb='8px'>
                Email<Text color={brandStars}>*</Text>
            </FormLabel>
            <Input
                key={'txt_email'}
                isRequired={true}
                variant='auth'
                fontSize='sm'
                ms={{ base: '0px', md: '0px' }}
                type='email'
                placeholder='mail@simmmple.com'
                mb='24px'
                fontWeight='500'
                size='lg'
                onChange={(e) => controller.changeForm(e.target.value, 'email')}
            />
            <FormLabel ms='4px' fontSize='sm' fontWeight='500' color={textColor} display='flex'>
                Password<Text color={brandStars}>*</Text>
            </FormLabel>
            <InputGroup size='md'>
                <Input
                    key={'txt_password'}
                    isRequired={true}
                    fontSize='sm'
                    placeholder='Min. 8 characters'
                    mb='24px'
                    size='lg'
                    type={controller.visiblePassword ? 'text' : 'password'}
                    variant='auth'
                    onChange={(e) => controller.changeForm(e.target.value, 'password')}
                />
                <InputRightElement display='flex' alignItems='center' mt='4px'>
                    <Icon
                        color={textColorSecondary}
                        _hover={{ cursor: 'pointer' }}
                        as={controller.visiblePassword ? RiEyeCloseLine : MdOutlineRemoveRedEye}
                        onClick={controller.setVisiblePassword}
                    />
                </InputRightElement>
            </InputGroup>
            <ServiceAuth controller={controller} />
            <SignInButton controller={controller} />
        </FormControl>
    )
}