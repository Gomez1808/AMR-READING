import { useRouter } from 'next/router';
import { Button, useColorMode } from "@chakra-ui/react"
import AuthPageController from "../../../../service/controller/page/auth_page_controller"

type ButtonModel = {
    controller: AuthPageController
}

export const SignInButton = ({ controller }: ButtonModel) => {
    const router = useRouter();
    const { colorMode, toggleColorMode } = useColorMode()

    const signInAction = async () => {
        var mode = colorMode === 'light' ? 'light' : 'dark'
        var result  = await controller.validateData(mode)

        if (result == true) {
            router.push('/dashboard');
        }
    }

    return (
        <Button
            fontSize='sm'
            variant='brand'
            fontWeight='500'
            w='100%'
            h='50'
            mb='24px'
            onClick={signInAction}
        >
            Sign In
        </Button>
    )
}