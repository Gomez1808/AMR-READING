import React, { useEffect } from 'react';
import Router from 'next/router'
import { Box, Flex } from '@chakra-ui/react';

import AuthLayout from './components/layout';

import { FormSignIn } from './components/form';
import { HeaderAuth } from './components/header';

import AuthPageController from '../../../service/controller/page/auth_page_controller';
import { LoadData, LoadDialog } from 'web/components/load';

const SignInView = () => {
	var controller = new AuthPageController()

	const checkSession = async () => {
		controller.setLoad(true)
		var result = await controller.checkSession()

		if (result == true) {
			Router.push('/dashboard')
		} else {
			controller.setLoad(false)
		}
	}

	useEffect(() => {
		checkSession()
	}, [])

	return controller.pageLoad == false
		? (
			<div>
				<AuthLayout illustrationBackground={'/img/auth/background.jpg'}>
					<Flex
						maxW={{ base: '100%', md: 'max-content' }}
						w='100%'
						mx={{ base: 'auto', lg: '0px' }}
						me='auto'
						h='100%'
						alignItems='start'
						justifyContent='center'
						mb={{ base: '30px', md: '60px' }}
						px={{ base: '25px', md: '0px' }}
						mt={{ base: '40px', md: '14vh' }}
						flexDirection='column'>

						<HeaderAuth />

						<Flex
							zIndex='2'
							direction='column'
							w={{ base: '100%', md: '420px' }}
							maxW='100%'
							background='transparent'
							borderRadius='15px'
							mx={{ base: 'auto', lg: 'unset' }}
							me='auto'
							mb={{ base: '20px', md: 'auto' }}>

							<FormSignIn controller={controller} />
						</Flex>
					</Flex>
				</AuthLayout>
				<LoadDialog isOpen={controller.preload} />
			</div>
		)
		: (
			<Box
				minHeight='100vh'
				height='100%'
				overflow='auto'
				position='relative'
				maxHeight='100%'
			>
				<LoadData />
			</Box>
		)
}

export default SignInView