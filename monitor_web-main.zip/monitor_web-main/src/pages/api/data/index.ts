import { NextApiRequest, NextApiResponse } from "next";
import { v4 } from "uuid";

import DataDataController from "../../../../service/controller/data/data_data";
import DataModel from "../../../../service/model/data";
import TelegramAppController from "../../../../service/controller/service/telegram_app_controller";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    try {
        if (req.method === 'POST') {
            const body = req.body;
            const dataData = new DataDataController()
            const teleApp = new TelegramAppController()

            body.forEach(async (e: any) => {
                var data = {
                    idData: v4(),
                    idCategory: e.idCategory,
                    valueData: e.valueData,
                    statusData: true,
                    createData: new Date()
                } as DataModel

                await dataData.addData(data)
            })

            await teleApp.sendTelegramMessage(body)

            res.status(200).json({ message: 'Data diterima!', data: body });
        } else {
            res.setHeader('Allow', ['POST']);
            res.status(405).end(`Method ${req.method} Not Allowed`);
        }
    } catch (error) {
        res.status(405).end(error);
    }
}