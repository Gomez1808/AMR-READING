import SignInView from "app/sign-in"

const SignInPage = () => {
    
    return (<SignInView/>)
}

export default SignInPage