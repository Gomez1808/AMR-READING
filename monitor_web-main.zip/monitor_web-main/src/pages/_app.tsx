import { ChakraProvider } from '@chakra-ui/react'
import { AppProps } from 'next/app'

import React from 'react'
import theme from 'web/theme/theme'

import 'web/styles/Fonts.css'
import 'web/styles/App.css'
import 'web/styles/Contact.css'
import 'web/styles/DatePicker.css'
import 'web/styles/Swiper.css'
import 'web/styles/MiniCalendar.css'
import Head from 'next/head'

import { RecoilEnv, RecoilRoot } from "recoil";
import RecoilNexus from 'recoil-nexus'

import 'react-toastify/dist/ReactToastify.css';

import { ToastBar } from '../../service/service/toast'

function MyApp({ Component, pageProps }: AppProps) {

  RecoilEnv.RECOIL_DUPLICATE_ATOM_KEY_CHECKING_ENABLED = false

  return (

    <RecoilRoot>
      <RecoilNexus />
      <ChakraProvider theme={theme}>
        <Head>
          <title>Monitor WEB</title>
          <meta name='viewport' content='width=device-width, initial-scale=1' />
          <meta name='theme-color' content='#000000' />
        </Head>
        <React.StrictMode>
          <Component {...pageProps} />
          <ToastBar />
        </React.StrictMode>
      </ChakraProvider>
    </RecoilRoot>
  )
}

export default MyApp
