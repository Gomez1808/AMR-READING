import Router from 'next/router'
import React, { useEffect } from 'react'
import MainAppController from '../../service/controller/service/main_app_controller'

export default function Home() {
  var controller = new MainAppController()

  const checkSession = async () => {
    var result = await controller.checkSession()

    if (result === true) {
      Router.push('/dashboard')
    } else {
      Router.push('/sign-in')
    }
  }

  useEffect(() => {
    checkSession()
  }, [])

  return <></>
}
