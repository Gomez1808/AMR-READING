import DashboardView from "app/main"

const DashboardPage = () => {
    
    return (<DashboardView/>)
}

export default DashboardPage