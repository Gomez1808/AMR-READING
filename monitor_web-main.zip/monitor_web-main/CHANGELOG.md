# Changelog
## [1.0.1] 2022-03-22
### Bug Fixing 
Auth layout fixed
## [1.0.0] 2022-10-17

### Original Release
- Added Typescript & NextJS